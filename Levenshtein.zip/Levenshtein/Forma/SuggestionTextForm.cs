﻿using LevenshteinLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forma
{
    public partial class SuggestionTextForm : Form
    {
        public SuggestionTextForm()
        {
            InitializeComponent();
        }
        List<string> ExtraWordsToReturn;
        private void txtWord_TextChanged(object sender, EventArgs e)
        {

            clearBoxes();
            var text = sender as TextBox;

            string retword = String.Empty;
            ExtraWordsToReturn = new List<string>();

            string lowerCaseText = text.Text.ToLower();

            var results = Words.listOfWords.Select(word => new
            {
                Word = word,
                Distance = Levenshtein.Compute(lowerCaseText, word)

            }).OrderBy(x=>x.Distance).ToList();

            var minLevenshtein = results.First().Distance;
            retword = results.First().Word;

            ExtraWordsToReturn = results
                .Where(x => x.Distance <= 2).Skip(1)
                .Select(x => x.Word)
                .ToList();

            if (!String.IsNullOrEmpty(text.Text))
            {
                txtSuggestion.Text = minLevenshtein != 0 ? retword : "";
                richSuggestions.AppendText(minLevenshtein != 0 ? string.Join("\r\n", ExtraWordsToReturn) : "");
            }
            
        }

        private void clearBoxes()
        {
            txtSuggestion.Text = String.Empty;
            richSuggestions.Clear();
        }
    }
}

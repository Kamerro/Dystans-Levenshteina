﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LevenshteinLib
{
    public class Levenshtein
    {

        public static int Compute(string s, string t)
        {
            //Określenie długości n i m na podstawie długości stringów przekazanych
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];


            if (n == 0)
            {
                return m;
            }

            if (m == 0)
            {
                return n;
            }

            //Wykreślenie w pionie i poziomie od 0 do x wartości
            for (int i = 0; i <= n; d[i, 0] = i++)
            {
            }

            for (int j = 0; j <= m; d[0, j] = j++)
            {
            }

            //Dla każdego wolnego miejsca w macierzy wykonaj: 
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    //Koszt = 0 jeżeli znaki są takie same, 1 jeżeli znaki są różne
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;

                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }
    }





    //Kod z podejściem innym niż wyznaczenie macierzy dla słów.
    //Można odkomentować i użyć zamiast Compute. Nie zawsze zwraca najmniejszą ilość transformacji, 
    //ale sprawdza się w większości przypadków.
    /*
    public static int calculateDistance(string wordA, string wordB)
    {
        bool marker = false;
        char[] chars = wordA.ToCharArray();
        char[] chars2 = wordB.ToCharArray();
        int totalDistance = 0;
        int distance = 0;
        while (true)
        {
            for (int i = 0; i < Math.Min(chars.Length, chars2.Length); i++)
            {
                if (marker == true)
                {
                    i = 0;
                    marker = false;
                }
                if (chars[i] != chars2[i])
                {
                    distance++;
                    chars2 = CalcSimplifiedDistance(chars, chars2, i);
                    marker = true;
                }
                else
                {
                    distance += 0;
                }
            }
            if (distance == 0)
            {
                totalDistance += Math.Abs(chars.Length - chars2.Length);
                break;
            }
            totalDistance += distance;
            distance = 0;
        }
        return totalDistance;
    }

    private static char[] CalcSimplifiedDistance(char[] chars, char[] chars2, int index)
    {
        //bez żadnych wartości:
        char[] optionReplace = new char[chars2.Length];
        char[] optionRemove = new char[chars2.Length - 1];
        char[] optionAdd = new char[chars2.Length + 1];

        int distanceOfRemoval = 0;
        int distanceOfextraCharacter = 0;
        int distanceOfReplace = 0;
        char[] copyOfArr = (char[])chars2.Clone();
        (optionReplace, distanceOfReplace) = calculateDistanceWithReplace(index, chars, copyOfArr);
        copyOfArr = (char[])chars2.Clone();
        (optionAdd, distanceOfextraCharacter) = calculateDistanceWithExtraCharacter(index, chars, copyOfArr);
        copyOfArr = (char[])chars2.Clone();
        (optionRemove, distanceOfRemoval) = calculateDistanceWithRemoval(index, chars, copyOfArr);

        //Jeżeli najkrótszy jest distance of replace, to->
        if (Math.Min(distanceOfReplace, Math.Min(distanceOfextraCharacter, distanceOfRemoval)) == distanceOfReplace)
        {
            return optionReplace;
        }

        else if (distanceOfextraCharacter <= distanceOfRemoval)
        {
            return optionAdd;
        }
        return optionRemove;

    }

    private static (char[], int) calculateDistanceWithExtraCharacter(int index, char[] chars, char[] chars2)
    {
        //Wykonaj dodanie, konwerowanie, później licz odległość:
        int odleglosc = 0;
        List<char> lista_nowa = new List<char>();
        for (int i = 0; i < chars2.Length; i++)
        {
            if (i != index)
                lista_nowa.Add(chars2[i]);

            else
            {
                lista_nowa.Add(chars[index]);
                lista_nowa.Add(chars2[i]);
            }

        }

        var newchars = lista_nowa.ToArray();
        //Powtarzalne. Można zamknąć w funkcji.
        for (int i = 0; i < Math.Min(chars.Length, chars2.Length); i++)
        {
            if (chars[i] != newchars[i])
            {
                odleglosc++;
            }
        }
        odleglosc += Math.Abs(newchars.Length - chars.Length);
        return (newchars, odleglosc);
    }

    private static (char[], int) calculateDistanceWithRemoval(int index, char[] chars, char[] chars2)
    {

        int odleglosc = 0;

        List<char> lista_nowa = new List<char>();
        for (int i = 0; i < chars2.Length; i++)
        {
            if (i != index)
                lista_nowa.Add(chars2[i]);

        }
        var newchars = lista_nowa.ToArray();

        for (int i = 0; i < Math.Min(chars.Length, newchars.Length); i++)
        {
            if (chars[i] != newchars[i])
            {
                odleglosc++;
            }
        }
        odleglosc += Math.Abs(newchars.Length - chars.Length);
        return (newchars, odleglosc);
    }

    private static (char[], int) calculateDistanceWithReplace(int index, char[] chars, char[] chars2)
    {
        //Zaprojektowany przykład działający dobrze tylko dla wyrazów które są równej długości.
        int odleglosc = 0;
        var newchars = (char[])chars2.Clone();
        newchars[index] = chars[index];
        for (int i = 0; i < Math.Min(chars.Length, newchars.Length); i++)
        {
            if (chars[i] != newchars[i])
            {
                odleglosc++;
            }
        }
        odleglosc += Math.Abs(newchars.Length - chars.Length);

        return (newchars, odleglosc);
    }

    */

}
